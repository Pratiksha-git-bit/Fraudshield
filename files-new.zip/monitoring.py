"""
FraudShield — drift monitoring.

Answers the question a hiring manager will actually ask: "how would you know
your model had gone stale in production?"

Three signals, in the order they become available in real life:

1. Prediction drift  — the score distribution shifts. Visible immediately.
2. Feature drift     — inputs shift. Visible immediately.
3. Performance decay — recall drops. Only visible once labels arrive, which
                       for fraud means 30-90 days later (chargeback lag).

Because of (3), 1 and 2 are your early-warning system, not a nice-to-have.

Run:
    python monitoring.py                 # simulates drift on a held-out slice
    python monitoring.py new_batch.csv   # score a real incoming batch
"""

import json
import sys
import numpy as np
import pandas as pd

import fraudshield_config as cfg
from features import engineer
from serving import load_bundle, score

# Industry-standard PSI bands.
PSI_STABLE = 0.10       # below this: no action
PSI_INVESTIGATE = 0.25  # 0.10-0.25: investigate. above 0.25: retrain candidate.


def psi(expected_edges, actual_values, eps=1e-6):
    """Population Stability Index against fixed baseline bin edges."""
    edges = np.array(expected_edges, dtype=float)
    edges = np.unique(edges)
    if len(edges) < 3:
        return 0.0
    edges[0], edges[-1] = -np.inf, np.inf

    # Baseline deciles mean each bin holds ~10% by construction.
    n_bins = len(edges) - 1
    exp_pct = np.full(n_bins, 1.0 / n_bins)

    act_counts, _ = np.histogram(np.asarray(actual_values, dtype=float), bins=edges)
    act_pct = act_counts / max(act_counts.sum(), 1)

    exp_pct = np.clip(exp_pct, eps, None)
    act_pct = np.clip(act_pct, eps, None)
    return float(np.sum((act_pct - exp_pct) * np.log(act_pct / exp_pct)))


def verdict(value):
    if value < PSI_STABLE:
        return "stable"
    if value < PSI_INVESTIGATE:
        return "investigate"
    return "retrain"


def run_drift_report(new_df: pd.DataFrame, top_n=10):
    baseline = json.loads(cfg.BASELINE_STATS_PATH.read_text())
    bundle = load_bundle()

    raw = new_df.drop(columns=["Class"], errors="ignore")
    scored = score(raw, bundle)

    # --- prediction drift ---
    pred_psi = psi(baseline["score_deciles"], scored["fraud_probability"])
    flag_rate = float(scored["flagged"].mean())
    baseline_flag_rate = baseline["fraud_rate"]

    # --- feature drift ---
    engineered = engineer(raw, cyclic=bundle["cyclic_hour"])

    rows = []
    for feat, stats in baseline["features"].items():
        if feat not in engineered.columns:
            rows.append({"feature": feat, "psi": np.nan, "status": "MISSING"})
            continue
        value = psi(stats["deciles"], engineered[feat])
        rows.append({
            "feature": feat,
            "psi": round(value, 4),
            "baseline_mean": round(stats["mean"], 4),
            "current_mean": round(float(engineered[feat].mean()), 4),
            "status": verdict(value),
        })

    feat_df = pd.DataFrame(rows).sort_values("psi", ascending=False)

    print(f"Model version: {bundle['version']}  |  batch rows: {len(raw):,}")
    print("\n=== PREDICTION DRIFT ===")
    print(f"Score PSI            : {pred_psi:.4f}  -> {verdict(pred_psi).upper()}")
    print(f"Flag rate            : {flag_rate:.4%}")
    print(f"Training fraud rate  : {baseline_flag_rate:.4%}")

    print(f"\n=== FEATURE DRIFT (top {top_n} by PSI) ===")
    print(feat_df.head(top_n).to_string(index=False))

    unstable = feat_df[feat_df["psi"] >= PSI_STABLE]
    print(f"\nFeatures above PSI {PSI_STABLE}: {len(unstable)} of {len(feat_df)}")

    action = "none"
    if pred_psi >= PSI_INVESTIGATE or (feat_df["psi"] >= PSI_INVESTIGATE).sum() >= 3:
        action = "RETRAIN — open a retraining ticket"
    elif pred_psi >= PSI_STABLE or len(unstable) >= 5:
        action = "INVESTIGATE — check upstream data pipeline first, then model"
    print(f"\nRecommended action: {action}")

    out = cfg.ARTIFACT_DIR / "drift_report.csv"
    feat_df.to_csv(out, index=False)
    print(f"Saved -> {out.name}")
    return {"prediction_psi": pred_psi, "flag_rate": flag_rate, "action": action}


def performance_decay(new_df: pd.DataFrame):
    """Only callable once labels land. Compares live recall/precision to the
    metrics stored in the bundle at training time."""
    if "Class" not in new_df.columns:
        print("No labels in this batch — performance decay not computable yet.")
        return None
    from sklearn.metrics import precision_score, recall_score

    bundle = load_bundle()
    scored = score(new_df.drop(columns=["Class"]), bundle)
    pred = scored["flagged"].astype(int)
    y = new_df["Class"]

    live = {
        "recall": float(recall_score(y, pred, zero_division=0)),
        "precision": float(precision_score(y, pred, zero_division=0)),
    }
    train = bundle["metrics"]
    print("\n=== PERFORMANCE DECAY ===")
    for k in ("recall", "precision"):
        delta = live[k] - train[k]
        print(f"{k:10s} train={train[k]:.3f}  live={live[k]:.3f}  delta={delta:+.3f}")
    if live["recall"] < cfg.PROMOTION_GATE["min_recall"]:
        print("ALERT: live recall below the promotion gate. Retrain.")
    return live


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    simulate = "--simulate" in sys.argv

    if args:
        batch = pd.read_csv(args[0])
    else:
        # A time-based split cannot demonstrate drift on this dataset: it spans
        # only ~48 hours, so the tail is one narrow slice of hour_of_day and any
        # "drift" it shows is a sampling artifact, not a real distribution shift.
        # A random sample is the honest no-drift control.
        full = pd.read_csv(cfg.DATA_PATH)
        batch = full.sample(frac=0.2, random_state=7)
        print("No batch given -- using a random 20% sample as a no-drift control.\n")

    if simulate:
        # Inject drift so you can show the monitor actually firing. Shifts the
        # two features the model leans on hardest plus the amount distribution,
        # which is what a merchant-mix change or an upstream pipeline bug looks
        # like in practice.
        batch = batch.copy()
        batch["V14"] = batch["V14"] - 1.5
        batch["V17"] = batch["V17"] * 1.8
        batch["Amount"] = batch["Amount"] * 2.5
        print("--simulate: injected synthetic drift into V14, V17 and Amount.\n")

    run_drift_report(batch)
    performance_decay(batch)
